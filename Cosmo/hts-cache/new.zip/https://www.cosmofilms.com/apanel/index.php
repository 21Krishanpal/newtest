
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<meta charset="utf-8">

<title>COSMO FILMS</title>

<script type="text/javascript" src="backend-js/csshorizontalmenu.js"> </script>



<script type="text/javascript" src="backend-js/common.js"></script>

<script type="text/javascript" src="backend-js/epoch_classes.js"></script>

<script type="text/javascript" src="backend-js/jquery.min.js"></script>

<script type="text/javascript" src="backend-js/prototype.js"></script>



<script type="text/javascript" src="../filemanager_in_ckeditor/js/ckeditor/ckeditor.js"></script>

<script src="../filemanager_in_ckeditor/sample.js" type="text/javascript"></script>

<link href="../filemanager_in_ckeditor/sample.css" rel="stylesheet" type="text/css" />

<link href="../filemanager_in_ckeditor/js/ckeditor/skins/kama/editor.css" rel="stylesheet" type="text/css" />


<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="backend-stylesheet/backend-stylesheet.css" rel="stylesheet" type="text/css">
<link href="backend-stylesheet/bootstrap.css" rel="stylesheet" type="text/css">



<link href="backend-js/calender.css" rel="stylesheet"  type="text/css" >



<!-- ///////////  Just For Lightbox Start  ///////////// -->

	<script src="lightbox/nav/jquery.min.js"></script>

	<link rel="stylesheet" href="lightbox/visuallightbox.css" type="text/css" media="screen" />

	<script src="lightbox/visuallightbox.js" type="text/javascript"></script>

	<script src="lightbox/vlbdata.js" type="text/javascript"></script>

<!-- ///////////  Just For Lightbox Ends  ///////////// -->
<script>
// Javascript originally by Patrick Griffiths and Dan Webb.
// http://htmldog.com/articles/suckerfish/dropdowns/
sfHover = function() {
   var sfEls = document.getElementById("navbar").getElementsByTagName("li");
   for (var i=0; i<sfEls.length; i++) {
      sfEls[i].onmouseover=function() {
         this.className+=" hover";
      }
      sfEls[i].onmouseout=function() {
         this.className=this.className.replace(new RegExp(" hover\\b"), "");
      }
   }
}
if (window.attachEvent) window.attachEvent("onload", sfHover);
</script>


</head><body onload="get_sc();">
<div class="clear"></div>
<div class="middle-outer-wrapper">
  


<div align="center" class="logo-container">



	<!--<img src="image/logo.png" alt="" height="91" />-->

      <img src="image/logo.png" />

</div><!--logo-container-->




<div  class="login-container col-md-6 centered col-offset-6 floatnone"  >

		<form action="index.php" method="post">

                <div class="testi-enquiry-form-home">

                	<!--<label> User Name: </label>-->

                    <input type="text" name="username" placeholder="User Name" value="" class="textfield" autocomplete="off" />

                    <div class="error" id="unErr"></div>

                    <div class="clear"></div>

                </div><!--testi-enquiry-form-->

                <div class="clear"></div>



                <div class="testi-enquiry-form-home">

                	<!--<label> Password: </label>-->

                    <input type="password" name="password" placeholder="Password" value="" class="pass" />

                    <div class="error" id="emailErr"></div>

                    <div class="clear"></div>

                </div><!--testi-enquiry-form-->

                <div class="clear"></div>



                <div class="testi-enquiry-submit-home">

                

                    <input name="signin" type="submit" class="submit" value="SIGN IN" />

                    <div class="clear"></div>

                </div><!--testi-enquiry-submit-->

				

				<div class="testi-enquiry-reg-form">

                	

                    <div class="clear"></div>

                </div><!--testi-enquiry-form-->

                <div class="clear"></div>

		</form>

                <div class="clear"></div>

            </div><!--login-container-->
            
            <div class="clearfix"></div>  <div class="middle-wrapper">
        
  </div>
  <!--middle-wrapper--> 
</div>
<!--middle-outer-wrapper-->
<div class="clear"></div>
<div class="outer-footer">

    	<div align="center" class="footer-container">

				<p>&copy; 2023 Cosmofilms	</p><p> Powered By : </p>

        	<div class="clear"></div>

        </div><!--footer-container-->

    </div><!--outer-footer--><div class="clear"></div>
</body>
</html>
